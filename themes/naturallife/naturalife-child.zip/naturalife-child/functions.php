<?php
/**
 * Natura Life Child Theme Functions File
 *
 * @author      RT-Themes
 * @since       1.0
 * @version     1.0
 */

 