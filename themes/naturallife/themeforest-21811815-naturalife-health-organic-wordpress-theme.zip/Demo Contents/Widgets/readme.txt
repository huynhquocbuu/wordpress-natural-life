IMPORTING DEMO WEBSITE WIDGETS
You can import the widget files by using this free “Widget Importer & Exporter” plugin https://wordpress.org/plugins/widget-importer-exporter/

